import { Add, Point } from "./Module";

console.log("Addition is : " + Add(30, 40));

var point = new Point(100, 200);
console.log(`Point [x,y]:[${point.x},${point.y}]`);
