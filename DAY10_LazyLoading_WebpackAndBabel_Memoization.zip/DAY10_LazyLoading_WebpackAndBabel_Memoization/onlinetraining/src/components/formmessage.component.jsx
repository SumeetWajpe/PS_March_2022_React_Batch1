import React, { useState } from "react";
import { Message } from "./message.component";

export default function FormMessage() {
  let [message, setMessage] = useState("Hello");
  return (
    <div>
      <label htmlFor="txtMsg">Message : </label>{" "}
      <input
        type="text"
        id="txtMsg"
        onInput={(e) => setMessage(e.target.value)}
      />{" "}
      <br />
      <Message msg={message} />
    </div>
  );
}
