import React, { Component, useContext } from "react";

var CounterContext = React.createContext({ count: 0 });
var AgeContext = React.createContext(18);

export default class CounterProvider extends Component {
  constructor(props) {
    super(props);
    this.state = { count: 100 };
  }
  render() {
    return (
      <CounterContext.Provider
        value={{
          counterstate: this.state,
          incrementCount: () => this.setState({ count: this.state.count + 1 }),
        }}
      >
        {this.props.children}
      </CounterContext.Provider>
    );
  }
}

export class GrandParent extends Component {
  render() {
    return (
      <div>
        <CounterProvider>
          <Parent />
        </CounterProvider>
      </div>
    );
  }
}

export class Parent extends Component {
  render() {
    return (
      <AgeContext.Provider value={20}>
        <Child />
      </AgeContext.Provider>
    );
  }
}

//Parent as a provider
// export class Parent extends Component {
//   render() {
//     return (
//       <CounterContext.Provider
//         value={{
//           counterstate: { count: 2000 },
//         }}
//       >
//         <Child />
//       </CounterContext.Provider>
//     );
//   }
// }

// Parent as a consumer

// export class Parent extends Component {
//   static contextType = CounterContext; // only with classes
//   render() {
//     return (
//       <div>
//         <strong>Count (Parent) : {this.context.counterstate.count}</strong>
//         <hr />
//         <Child />
//       </div>
//     );
//   }
// }
//1st way
// export class Child extends Component {
//   static contextType = CounterContext; // only with classes
//   render() {
//     return (
//       <div>
//         <strong>Count : {this.context.counterstate.count}</strong>
//       </div>
//     );
//   }
// }

//2nd way

// export class Child extends Component {
//   render() {
//     return (
//       <div>
//         <CounterContext.Consumer>
//           {(value) => <strong>Count : {value.counterstate.count}</strong>}
//         </CounterContext.Consumer>
//       </div>
//     );
//   }
// }

//3rd Way

export function Child() {
  const counterCtx = useContext(CounterContext); // only wrks with functional component
  const ageCtx = useContext(AgeContext);
  return (
    <div>
      <p>Age : {ageCtx} </p>
      <strong>Count (Child) : {counterCtx.counterstate.count}</strong>{" "}
      <button
        className="btn btn-primary"
        onClick={() => counterCtx.incrementCount()}
      >
        ++
      </button>
    </div>
  );
}

// export default function GrandParent() {
//   return <div></div>;
// }

// export default function Parent() {
//     return <div></div>;
//   }

//   export default function Child() {
//     return <div></div>;
//   }
