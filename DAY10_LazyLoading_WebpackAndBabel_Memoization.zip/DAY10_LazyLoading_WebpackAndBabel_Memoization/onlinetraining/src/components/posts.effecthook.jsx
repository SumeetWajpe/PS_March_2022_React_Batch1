import React, { useEffect, useState } from "react";
import axios from "axios";
export default function PostsWithEffectHook() {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    let thePromise = axios.get("https://jsonplaceholder.typicode.com/posts");
    thePromise.then((response) => {
      setPosts(response.data);
    });
  }, []);
  let postsToBeCreated = posts.map((post) => (
    <li key={post.id} className="list-group-item">
      {post.title}
    </li>
  ));
  return (
    <div>
      <header>
        <h1>AllPosts</h1>
      </header>
      <ul className="list-group">{postsToBeCreated}</ul>
    </div>
  );
}
