import axios from "axios";
const COURSE_INCREMENT_LIKES = "COURSE_INCREMENT_LIKES";
export function IncrementLikes(theCourseId) {
  return { type: COURSE_INCREMENT_LIKES, theCourseId };
}

export function DeleteCourse(theCourseId) {
  return { type: "DELETE_COURSE", theCourseId };
}

export function AddCourse(newCourse) {
  return { type: "ADD_NEW_COURSE", newCourse };
}
export function DeletePost() {
  return { type: "DELETE_POST" };
}

export function FetchPosts(thePosts) {
  return { type: "FETCH_POSTS", thePosts };
}

export function FetchPostsAsync() {
  return { type: "FETCH_POSTS_ASYNC" };
}

// Using Thunk
// export function FetchPosts(thePosts) {
//   return { type: "FETCH_POSTS", thePosts };
// }

// export function FetchPostsAsync() {
//   return (dispatch) => {
//     axios
//       .get("https://jsonplaceholder.typicode.com/posts")
//       .then((response) => dispatch(FetchPosts(response.data)))
//       .catch((err) => console.log(err));
//   };
// }
