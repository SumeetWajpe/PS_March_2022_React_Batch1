import React from "react";
import { useDispatch } from "react-redux";
import { IncrementLikes, DeleteCourse } from "../actions/actioncreators";

export default function Course(props) {
  var dispatch = useDispatch();
  //   console.log(props);
  let ratings = [];
  for (let index = 0; index < props.coursedetails.rating; index++) {
    ratings.push(<i key={index} className="fa-solid fa-star"></i>);
  }
  return (
    <div className="col-md-3 my-2">
      <div className="card p-2">
        <img
          height="200px"
          src={props.coursedetails.imageUrl}
          alt={props.coursedetails.name}
          className="card-img-top"
        />
        <div className="card-body">
          {ratings}

          <h4 className="card-title">{props.coursedetails.title}</h4>
          <h5 className="card-text">₹. {props.coursedetails.price}</h5>

          <button
            className="btn btn-primary"
            onClick={() => dispatch(IncrementLikes(props.coursedetails.id))}
          >
            {props.coursedetails.likes}{" "}
            <i className="fa-solid fa-thumbs-up"></i>
          </button>

          <button
            className="btn btn-danger mx-1"
            onClick={() => dispatch(DeleteCourse(props.coursedetails.id))}
          >
            <i className="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </div>
    </div>
  );
}

// import React from "react";

// export default function Course(props) {
//   //   console.log(props);
//   let ratings = [];
//   for (let index = 0; index < props.coursedetails.rating; index++) {
//     ratings.push(<i key={index} className="fa-solid fa-star"></i>);
//   }
//   return (
//     <div className="col-md-3 my-2">
//       <div className="card p-2">
//         <img
//           height="200px"
//           src={props.coursedetails.imageUrl}
//           alt={props.coursedetails.name}
//           className="card-img-top"
//         />
//         <div className="card-body">
//           {ratings}

//           <h4 className="card-title">{props.coursedetails.title}</h4>
//           <h5 className="card-text">₹. {props.coursedetails.price}</h5>

//           <button
//             className="btn btn-primary"
//             onClick={() => props.IncrementLikes(props.coursedetails.id)}
//           >
//             {props.coursedetails.likes}{" "}
//             <i className="fa-solid fa-thumbs-up"></i>
//           </button>

//           <button
//             className="btn btn-danger mx-1"
//             onClick={() => props.DeleteCourse(props.coursedetails.id)}
//           >
//             <i className="fa-solid fa-trash-can"></i>
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }
