import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";

import { useParams } from "react-router-dom";

export default function PostDetails() {
  const { posts } = useSelector((store) => store);
  let thePost;
  //   const [thePost, setPost] = useState({});
  let { id } = useParams();

  useEffect(() => {
    thePost = posts.find((p) => p.id === id);
  });

  return (
    <div className="alert alert-secondary my-4">
      <h2>Post Details for {id}</h2>
      <h3>User Id : {thePost?.userId}</h3>
      <h3>Body : {thePost?.body}</h3>
      <h3>Title : {thePost?.title}</h3>
    </div>
  );
}
