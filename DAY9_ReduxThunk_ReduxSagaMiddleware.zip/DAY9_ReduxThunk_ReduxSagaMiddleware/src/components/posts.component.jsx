import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import axios from "axios";
import { FetchPostsAsync } from "../actions/actioncreators";

export default function Posts() {
  const { posts } = useSelector((store) => store);
  var dispatch = useDispatch();

  let contentToBeRendered;
  let postsToBeCreated = posts.map((post) => (
    <li key={post.id} className="list-group-item">
      <Link to={`/postdetails/${post.id}`}>{post.title}</Link>
    </li>
  ));

  if (posts.length === 0) {
    contentToBeRendered = (
      <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" />
    );
  } else {
    contentToBeRendered = <ul className="list-group">{postsToBeCreated}</ul>;
  }

  // useEffect(() => {
  //   // ajax
  //   dispatch(FetchPostsAsync());
  // }, []);

  return (
    <div>
      <header>
        <h1>AllPosts</h1>
        <button onClick={() => dispatch(FetchPostsAsync())}>
          Get All Posts !
        </button>
      </header>
      {contentToBeRendered}
    </div>
  );
}
