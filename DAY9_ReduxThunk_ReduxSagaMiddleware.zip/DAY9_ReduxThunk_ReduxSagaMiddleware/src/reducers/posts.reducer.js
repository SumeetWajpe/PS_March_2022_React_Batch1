export function posts(defStore = [], action) {
  switch (action.type) {
    case "DELETE_POST":
      console.log(action);
      console.log("Posts reducer called !");
      console.log(defStore);

      return defStore;

    case "FETCH_POSTS":
      return action.thePosts;

    default:
      return defStore;
  }
}
