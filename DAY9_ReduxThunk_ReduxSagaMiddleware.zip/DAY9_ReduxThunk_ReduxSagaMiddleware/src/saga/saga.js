import axios from "axios";
import { call, put, retry, takeLatest } from "redux-saga/effects";

const getPosts = () => axios.get("https://jsonplaceholder.typicode.com/posts");

// worker saga
function* FetchPostsUsingAPI() {
  try {
    const response = yield call(getPosts); //make the async call
    yield put({ type: "FETCH_POSTS", thePosts: response.data });
  } catch (error) {
    yield put({ type: "FETCH_POSTS_FAILED" });
  }
}

function* FetchPostsWithRetry() {
  try {
    let duration = 1000;
    const response = yield retry(3, duration * 10, getPosts);
    yield put({ type: "FETCH_POSTS", thePosts: response.data });
  } catch (error) {
    yield put({ type: "FETCH_POSTS_FAILED" });
  }
}

// main saga
export default function* mySaga() {
  //   yield takeLatest("FETCH_POSTS_ASYNC", FetchPostsUsingAPI);
  yield takeLatest("FETCH_POSTS_ASYNC", FetchPostsWithRetry);
}
