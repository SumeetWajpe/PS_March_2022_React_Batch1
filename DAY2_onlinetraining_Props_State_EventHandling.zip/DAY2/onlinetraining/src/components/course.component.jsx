import React from "react";
class Course extends React.Component {
  constructor(props) {
    super(props);
    this.state = { likes: this.props.coursedetails.likes, dislikes: 50 };
  }

  IncrementLikes() {
    console.log("Within Increment Likes !");
    // this.props.likes += 1; // props are readonly!
    // this.state.likes++; // state is immutable !
    this.setState({ likes: this.state.likes + 1 });
  }

  DecrementLikes() {
    console.log("Within Decrement Likes !");

    this.setState({ dislikes: this.state.dislikes + 1 });
  }
  render() {
    console.log("Within render !");
    let ratings = [];
    for (let index = 0; index < this.props.coursedetails.rating; index++) {
      ratings.push(<i className="fa-solid fa-star"></i>);
    }
    return (
      <div className="col-md-3 my-2">
        <div className="card p-2">
          <img
            height="200px"
            src={this.props.coursedetails.imageUrl}
            alt={this.props.coursedetails.name}
            className="card-img-top"
          />
          <div className="card-body">
            {ratings}

            <h4 className="card-title">{this.props.coursedetails.title}</h4>
            <h5 className="card-text">₹. {this.props.coursedetails.price}</h5>
            <button
              className="btn btn-primary"
              onClick={() => this.IncrementLikes()}
            >
              {this.state.likes} <i className="fa-solid fa-thumbs-up"></i>
            </button>

            <button
              className="btn btn-warning mx-1"
              onClick={() => this.DecrementLikes()}
            >
              {this.state.dislikes} <i className="fa-solid fa-thumbs-down"></i>
            </button>

            <button className="btn btn-danger mx-1">
              <i className="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Course;
