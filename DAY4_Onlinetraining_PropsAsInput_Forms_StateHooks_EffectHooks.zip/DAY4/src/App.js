import Counter from "./components/counter.statehook";
import FormMessage from "./components/formmessage.component";
import GetPostById from "./components/getpostbyid.component";
import ListOfCourses from "./components/listofcourses.component";
import { Message } from "./components/message.component";
import Posts from "./components/posts.component";
import PostsWithEffectHook from "./components/posts.effecthook";

function App() {
  return (
    <div>
      <ListOfCourses />
      {/* <Posts /> */}
      {/* <Message msg="Hello" /> */}
      {/* <Counter /> */}
      {/* <PostsWithEffectHook /> */}
      {/* <GetPostById /> */}
      {/* <FormMessage /> */}
    </div>
  );
}

export default App;
