import React, { useState } from "react";

export default function Counter() {
  let [counter, setCount] = useState({ count: 100 }); // [countervalue,aMethodChangesCounterValue]
  let [age, setAge] = useState(35); // [countervalue,aMethodChangesCounterValue]

  return (
    <div>
      <strong>Count : {counter.count}</strong>
      <br />
      <strong>Age : {age}</strong>
      <br />{" "}
      <button
        className="btn btn-primary m-1"
        onClick={() => setCount({ count: counter.count + 1 })}
      >
        Count ++
      </button>
      <button className="btn btn-primary m-1" onClick={() => setAge(age + 1)}>
        Age ++
      </button>
    </div>
  );
}
