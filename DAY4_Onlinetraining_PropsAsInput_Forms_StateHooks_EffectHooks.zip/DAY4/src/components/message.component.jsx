import React from "react";

//1. No this.state, this.setState() !   16.8 -> state hooks
//2. No render()
//3. No this.props
//4. No LifeCycleMethods ! 16.8 -> effect hooks

export function Message(props) {
  return <h1>{props.msg}</h1>;
}

// export var Message = () => (
//   <>
//     <h1>Hello from Functional Component !</h1>
//     <p>This is a functional component !</p>
//   </>
// );
