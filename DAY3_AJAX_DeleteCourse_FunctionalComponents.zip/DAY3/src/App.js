import ListOfCourses from "./components/listofcourses.component";
import { Message } from "./components/message.component";
import Posts from "./components/posts.component";

function App() {
  return (
    <div>
      {/* <ListOfCourses /> */}
      {/* <Posts /> */}

      <Message msg="Hello" />
    </div>
  );
}

export default App;
