import React, { Component } from "react";
import axios from "axios";

export default class Posts extends Component {
  constructor(props) {
    super(props);
    this.state = { posts: [] };
  }
  componentDidMount() {
    //ajax  XMLHttpRequest | fetch | axios

    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => this.setState({ posts: response.data }))
      .catch((err) => console.log(err));
  }

  render() {
    let postsToBeCreated = this.state.posts.map((post) => (
      <li key={post.id} className="list-group-item">
        {post.title}
      </li>
    ));
    return (
      <div>
        <header>
          <h1>AllPosts</h1>
        </header>
        <ul className="list-group">{postsToBeCreated}</ul>
      </div>
    );
  }
}
