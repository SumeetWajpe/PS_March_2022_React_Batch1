import ListOfCourses from "./listofcourses.component";
import { BrowserRouter, Route, Routes, Link } from "react-router-dom";
import Posts from "./posts.component";
import PostDetails from "./postdetails.component";
import NewCourse from "./newcourse.component";

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Online Training
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link active" to="/">
                  Courses
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/posts">
                  Posts
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/newcourse">
                  New Course
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<ListOfCourses />} />
        <Route path="/posts" element={<Posts />} />
        <Route path="/postdetails/:id" element={<PostDetails />} />
        <Route path="/newcourse" element={<NewCourse />} />

        <Route
          path="*"
          element={
            <>
              {/* Better to have an Error Component ! */}
              <h1 style={{ color: "red" }}>Resource not found !</h1>
              <img src="https://www.elegantthemes.com/blog/wp-content/uploads/2020/02/000-404.png" />
            </>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
