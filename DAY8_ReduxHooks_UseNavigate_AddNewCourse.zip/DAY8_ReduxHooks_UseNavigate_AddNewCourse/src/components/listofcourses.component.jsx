import React from "react";
import { useSelector } from "react-redux";
import Course from "./course.component";

// using useSelector() fromm react-redux
export default function ListOfCourses() {
  const { courses } = useSelector((store) => store);
  let coursesToBeCreated = courses.map((course) => (
    <Course coursedetails={course} key={course.id} />
  ));
  return (
    <div>
      <h1> List Of Courses</h1>
      <div className="row">{coursesToBeCreated}</div>
    </div>
  );
}

// using connect and expecting props
// import React from "react";
// import Course from "./course.component";

// export default function ListOfCourses(props) {
//   let coursesToBeCreated = props.allCourses.map((course) => (
//     <Course coursedetails={course} key={course.id} {...props} />
//   ));
//   return (
//     <div>
//       <h1> List Of Courses</h1>
//       <div className="row">{coursesToBeCreated}</div>
//     </div>
//   );
// }
