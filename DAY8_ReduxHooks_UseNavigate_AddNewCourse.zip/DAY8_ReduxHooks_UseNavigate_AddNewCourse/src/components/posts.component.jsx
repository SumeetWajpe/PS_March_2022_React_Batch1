import React from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";

export default function Posts() {
  const { posts } = useSelector((store) => store);

  let contentToBeRendered;
  let postsToBeCreated = posts.map((post) => (
    <li key={post.id} className="list-group-item">
      <Link to={`/postdetails/${post.id}`}>{post.title}</Link>
    </li>
  ));

  if (posts.length === 0) {
    contentToBeRendered = (
      <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" />
    );
  } else {
    contentToBeRendered = <ul className="list-group">{postsToBeCreated}</ul>;
  }
  return (
    <div>
      <header>
        <h1>AllPosts</h1>
      </header>
      {contentToBeRendered}
    </div>
  );
}
