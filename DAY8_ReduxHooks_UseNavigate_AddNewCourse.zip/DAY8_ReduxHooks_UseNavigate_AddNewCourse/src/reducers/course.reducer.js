export function courses(defStore = [], action) {
  let index;
  switch (action.type) {
    case "COURSE_INCREMENT_LIKES":
      console.log("Courses reducer called !");
      index = defStore.findIndex((c) => c.id === action.theCourseId);

      return [
        ...defStore.slice(0, index),
        {
          ...defStore[index],
          likes: defStore[index].likes + 1,
        },
        ...defStore.slice(index + 1),
      ]; // changed defStore with incremented likes !

    case "DELETE_COURSE":
      // return defStore.filter(condn)
      index = defStore.findIndex((c) => c.id === action.theCourseId);
      return [...defStore.slice(0, index), ...defStore.slice(index + 1)];

    case "ADD_NEW_COURSE":
      return [...defStore, action.newCourse];

    default:
      return defStore;
  }
}
