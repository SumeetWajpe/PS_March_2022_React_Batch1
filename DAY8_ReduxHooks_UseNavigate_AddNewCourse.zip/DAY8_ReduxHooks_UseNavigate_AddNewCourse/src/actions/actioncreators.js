const COURSE_INCREMENT_LIKES = "COURSE_INCREMENT_LIKES";
export function IncrementLikes(theCourseId) {
  return { type: COURSE_INCREMENT_LIKES, theCourseId };
}

export function DeleteCourse(theCourseId) {
  return { type: "DELETE_COURSE", theCourseId };
}

export function AddCourse(newCourse) {
  return { type: "ADD_NEW_COURSE", newCourse };
}
export function DeletePost() {
  return { type: "DELETE_POST" };
}
