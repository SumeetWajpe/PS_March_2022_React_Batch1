import React from "react";
export class Message extends React.Component {
  render() {
    return (
      <div>
        <h4>{this.props.msg} !</h4>
        <img height="200px" width="300px" src={this.props.sourceImage} />
      </div>
    );
  }
}
