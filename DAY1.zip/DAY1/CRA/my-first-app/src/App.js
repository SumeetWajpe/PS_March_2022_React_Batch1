import React from "react";
import { Message } from "./message.component";

class App extends React.Component {
  constructor() {
    super();
    this.msgOne = {
      message: "Hello",
      imageUrl:
        "https://upload.wikimedia.org/wikipedia/en/thumb/6/6b/Hello_Web_Series_%28Wordmark%29_Logo.png/1200px-Hello_Web_Series_%28Wordmark%29_Logo.png",
    };
  }
  render() {
    return (
      <div>
        <Message msg={this.msgOne.message} sourceImage={this.msgOne.imageUrl} />
        <hr />
        <Message
          msg="Hey"
          sourceImage="https://media-exp1.licdn.com/dms/image/C4E1BAQFCUbmP6ZyCCA/company-background_10000/0/1631705458772?e=2147483647&v=beta&t=TpfOjJeCFiH1Wxz9sP5q_E61iuqHE9fkN8inxIc7zlc"
        />
        ;
      </div>
    );
  }
}

export default App;
