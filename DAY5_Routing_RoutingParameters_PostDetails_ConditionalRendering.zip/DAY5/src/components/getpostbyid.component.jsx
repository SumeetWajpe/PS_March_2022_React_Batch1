import axios from "axios";
import React, { useEffect, useState } from "react";

export default function GetPostById() {
  let [thePost, setThePost] = useState({ title: "" });
  let [thePostId, setThePostId] = useState(1);

  useEffect(() => {
    let aPromise = axios.get(
      `https://jsonplaceholder.typicode.com/posts/${thePostId}`
    );
    aPromise.then((response) => setThePost(response.data));
  }, [thePostId]);
  return (
    <div>
      <label htmlFor="txtPostId">Enter Post Id : </label>
      <input
        type="text"
        id="txtPostId"
        onInput={(e) => setThePostId(e.target.value)}
      />{" "}
      <br />
      <p>{thePost.title}</p>
    </div>
  );
}
