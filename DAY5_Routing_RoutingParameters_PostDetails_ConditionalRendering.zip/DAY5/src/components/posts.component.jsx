import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

export default class Posts extends Component {
  constructor(props) {
    super(props);
    this.state = { posts: [] };
  }
  componentDidMount() {
    //ajax  XMLHttpRequest | fetch | axios

    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => this.setState({ posts: response.data }))
      .catch((err) => console.log(err));
  }

  render() {
    let contentToBeRendered;
    let postsToBeCreated = this.state.posts.map((post) => (
      <li key={post.id} className="list-group-item">
        <Link to={`/postdetails/${post.id}`}>{post.title}</Link>
      </li>
    ));

    if (this.state.posts.length === 0) {
      contentToBeRendered = (
        <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" />
      );
    } else {
      contentToBeRendered = <ul className="list-group">{postsToBeCreated}</ul>;
    }

    return (
      <div>
        <header>
          <h1>AllPosts</h1>
        </header>
        {contentToBeRendered}
      </div>
    );
  }
}

// <div>
// <header>
//   <h1>AllPosts</h1>
// </header>
// {this.state.posts.length === 0 ? (
//   <strong>Loading..</strong>
// ) : (
//   <ul className="list-group">{postsToBeCreated}</ul>
// )}
// </div>
