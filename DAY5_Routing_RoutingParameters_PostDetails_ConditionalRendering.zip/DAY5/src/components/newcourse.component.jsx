import React, { useState } from "react";

export default function NewCourse(props) {
  let [newCourse, setNewCourse] = useState({});
  return (
    <div className="col-md-4">
      <h1>New Course </h1>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          props.AddCourse(newCourse);
        }}
      >
        <label htmlFor="txtCourseId">Course Id : </label>{" "}
        <input
          required
          type="number"
          className="form-control"
          id="txtCourseId"
          onChange={(e) => setNewCourse({ ...newCourse, id: e.target.value })}
        />
        <label htmlFor="txtCourseName">Course Name : </label>{" "}
        <input
          type="text"
          className="form-control"
          id="txtCourseName"
          onChange={(e) => setNewCourse({ ...newCourse, name: e.target.value })}
        />
        <label htmlFor="txtCoursePrice">Course Price : </label>{" "}
        <input
          type="number"
          className="form-control"
          id="txtCoursePrice"
          onChange={(e) =>
            setNewCourse({ ...newCourse, price: e.target.value })
          }
        />
        <label htmlFor="txtCourseRating">Course Rating : </label>{" "}
        <input
          type="number"
          className="form-control"
          id="txtCourseRating"
          onChange={(e) =>
            setNewCourse({ ...newCourse, rating: e.target.value })
          }
        />
        <label htmlFor="txtCourseLikes">Course Likes : </label>{" "}
        <input
          type="number"
          className="form-control"
          id="txtCourseLikes"
          onChange={(e) =>
            setNewCourse({ ...newCourse, likes: +e.target.value })
          }
        />
        <label htmlFor="txtCourseImage">Course Image : </label>{" "}
        <input
          type="text"
          className="form-control"
          id="txtCourseImage"
          onChange={(e) =>
            setNewCourse({ ...newCourse, imageUrl: e.target.value })
          }
        />
        <button className="btn btn-success my-1">Add New Course</button>
      </form>
    </div>
  );
}
