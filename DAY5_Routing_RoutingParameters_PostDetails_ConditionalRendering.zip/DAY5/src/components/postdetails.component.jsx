import React, { useEffect, useState } from "react";

import { useParams } from "react-router-dom";

export default function PostDetails() {
  const [thePost, setPost] = useState({});
  let { id } = useParams();
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts/" + id)
      .then((res) => res.json())
      .then((p) => setPost(p));
  }, []);
  return (
    <div className="alert alert-secondary my-4">
      <h2>Post Details for {id}</h2>
      <h3>User Id : {thePost.userId}</h3>
      <h3>Body : {thePost.body}</h3>
      <h3>Title : {thePost.title}</h3>
    </div>
  );
}
