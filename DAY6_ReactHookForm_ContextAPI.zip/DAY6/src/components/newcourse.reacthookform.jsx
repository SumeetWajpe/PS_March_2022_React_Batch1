import React from "react";
import { useForm } from "react-hook-form";

export default function NewCourseWithHookForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  return (
    <div className="col-md-4">
      <h1>New Course </h1>
      <form
        onSubmit={handleSubmit((data) => {
          console.log(data);
        })}
      >
        <label htmlFor="txtCourseId">Course Id : </label>{" "}
        <input
          type="number"
          className="form-control"
          id="txtCourseId"
          {...register("CourseId", { required: "CourseId is required !" })}
        />
        {errors.CourseId && (
          <p style={{ color: "red" }}>{errors.CourseId.message}</p>
        )}
        <label htmlFor="txtCourseName">Course Name : </label>{" "}
        <input
          type="text"
          className="form-control"
          id="txtCourseName"
          placeholder="Name maxlength 20 chars.."
          {...register("CourseName", {
            required: "Course Name is required !",
            maxLength: {
              value: 20,
              message: "You exceeded maxlength 20 !",
            },
          })}
        />
        {errors.CourseName && (
          <p style={{ color: "red" }}>{errors.CourseName.message}</p>
        )}
        <button className="btn btn-success my-1">Add New Course</button>
      </form>
    </div>
  );
}
