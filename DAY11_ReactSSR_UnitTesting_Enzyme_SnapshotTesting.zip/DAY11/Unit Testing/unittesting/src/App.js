import logo from "./logo.svg";
import "./App.css";
import React from "react";

class App extends React.Component {
  state = { count: 0 };
  render() {
    return (
      <>
        <p>Count : {this.state.count}</p>
        <button onClick={() => this.setState({ count: this.state.count + 1 })}>
          ++
        </button>
      </>
    );
  }
}

export default App;
