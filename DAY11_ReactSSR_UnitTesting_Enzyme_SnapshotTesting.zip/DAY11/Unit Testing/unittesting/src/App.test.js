// import { render, screen } from "@testing-library/react";
// import App from "./App";

// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/learn react/i);
//   expect(linkElement).toBeInTheDocument();
// });
import React from "react";
import Enzyme from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import { shallow } from "enzyme";
import App from "./App";

Enzyme.configure({ adapter: new Adapter() });

describe("state of counter", () => {
  it("counter is set to zero", () => {
    let appInstance = shallow(<App />);
    let count = appInstance.state().count;
    expect(count).toBe(0);
  });

  it("counter increments to 1", () => {
    let appInstance = shallow(<App />);
    let btn = appInstance.find("button");
    btn.simulate("click");
    let pText = appInstance.find("p").text();
    expect(pText).toEqual("Count : 1");
  });
});
