import "./App.css";
import React from "react";

function App() {
  return <h1>This is Server Side rendered !</h1>;
}

export default App;
