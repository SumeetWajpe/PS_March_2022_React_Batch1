export function courses(defStore = [], action) {
  switch (action.type) {
    case "COURSE_INCREMENT_LIKES":
      console.log("Courses reducer called !");
      console.log(defStore);
      return defStore;

    default:
      return defStore;
  }
}
