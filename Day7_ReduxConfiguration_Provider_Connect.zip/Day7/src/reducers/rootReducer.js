import { combineReducers } from "redux";
import { courses } from "./course.reducer";
import { posts } from "./posts.reducer";

var rootReducer = combineReducers({ courses, posts });
export default rootReducer;
