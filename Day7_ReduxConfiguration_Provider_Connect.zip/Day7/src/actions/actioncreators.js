const COURSE_INCREMENT_LIKES = "COURSE_INCREMENT_LIKES";
export function IncrementLikes() {
  return { type: COURSE_INCREMENT_LIKES };
}

export function DeleteCourse() {
  return { type: "DELETE_COURSE" };
}

export function DeletePost() {
  return { type: "DELETE_POST" };
}
