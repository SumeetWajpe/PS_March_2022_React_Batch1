import { createStore } from "redux";
import rootReducer from "../reducers/rootReducer";

var storeData = {
  courses: [{ id: 1, title: "Redux" }],
  posts: [{ id: 1, title: "Dummy Post" }],
};

export var store = createStore(rootReducer, storeData);
