function App(props) {
  console.log(props);
  return <div>Using Redux !</div>;
}

export default App;
